% This function transform a vector into a vector which contains all its unique elements
% but keeps these elements in the order of their first / last appearance (i.e. without sorting).

function out=SPIKY_f_unique_not_sorted(in,str)

if nargin<2
    str='first';
end
[~,c,~]=unique(in,str);
[~,f]=sort(c);
out=in(c(f));

