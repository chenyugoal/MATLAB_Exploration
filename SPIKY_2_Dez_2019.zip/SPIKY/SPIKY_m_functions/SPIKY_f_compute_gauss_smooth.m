% This function computes the Peri-Stimulus Time Histogram, smoothed with a Gaussian
% filter of kernel width "window"
% Copyright: Jude Mitchell, http://www.snl.salk.edu/~jude/sfn2008/index.html 

%**************************************************************
function output = SPIKY_f_compute_gauss_smooth(input, window)
% Smoothing function: 
% output = smooth(input, window)
% "Window" is the total kernel width.
% Input array must be one-dimensional.

input_dims = ndims(input);
input_size = size(input);
if input_dims > 2 || min(input_size) > 1
   disp('Input array is too large.');
   return
end

if input_size(2) > input_size(1)
   input = input';
   toggle_dims = 1;
else
   toggle_dims = 0;
end

if window/2 ~= round(window/2)
   window = window + 1;
end
halfwin = window/2;

input_length = length(input);
%********* gauss window +/- 1 sigma
x = -halfwin:1:halfwin;
kernel = exp(-x.^2/(window/2)^2);
kernel = kernel/sum(kernel);

padded(halfwin+1:input_length+halfwin) = input;
padded(1:halfwin) = ones(halfwin, 1)*input(1);
padded(length(padded)+1:length(padded)+halfwin) = ones(halfwin, 1)*input(input_length);

output = conv(padded, kernel);
output = output(window:input_length+window-1);

if toggle_dims == 1
   output = output';
end

return;

